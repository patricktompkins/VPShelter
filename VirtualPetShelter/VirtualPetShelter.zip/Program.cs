﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualPetShelter
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isEndProgram = false;
            int endProgram = 10;
            VirtualPetShelter myAnimalHouse = new VirtualPetShelter();

            do
            {
                //tick method
                //Ed.Tick();
                //place menu here
                Console.WriteLine("Welcome to the Unicorn Virtual Pet Shelter. What employee type are you?\n\n");
                Console.WriteLine("1. Manger");
                Console.WriteLine("2. Volunteer");
                Console.WriteLine();
                Console.Write("> ");
                endProgram = int.Parse(Console.ReadLine());
                Console.WriteLine();




                //Enter the display output 
                if (endProgram == 1)

                {
                    Console.WriteLine("Thank you for working at the Unicorn Pet Shelter!\n\n");
                    myAnimalHouse.MyPet1.Name = "Joey";
                    myAnimalHouse.MyPet2.Name = "Johnny";
                    myAnimalHouse.MyPet3.Name = "Dee Dee";
                    myAnimalHouse.MyPet4.Name = "Tommy";
                    myAnimalHouse.MyMan.Name = "Peter";
                    myAnimalHouse.MyVol.Name = "Tom";

                    Console.WriteLine("What would you like to do?");
                    Console.WriteLine("1. Adopt a pet");
                    Console.WriteLine("2. Feed the pets");
                    Console.WriteLine("3. Play with a pet");
                    Console.WriteLine("4. Pay the bills");
                    Console.WriteLine("5. Quit\n\n");
                    Console.Write("> ");
                    endProgram = int.Parse(Console.ReadLine());
                    Console.WriteLine();
                    if (endProgram == 1)
                    {
                        Console.WriteLine("Okay, so you'd like to adopt a pet. Please choose a pet.\n\n");
                        Console.WriteLine("For " + myAnimalHouse.MyPet1.Name + " type 1");
                        Console.WriteLine("For " + myAnimalHouse.MyPet2.Name + " type 2");
                        Console.WriteLine("For " + myAnimalHouse.MyPet3.Name + " type 3");
                        Console.WriteLine("For " + myAnimalHouse.MyPet4.Name + " type 4");
                        Console.WriteLine("Which pet would you like to adopt with?\n\n");
                        Console.Write("> ");
                        endProgram = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        if(endProgram == 1)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet1.Name + ".");

                        }
                        else if (endProgram == 2)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet2.Name + ".");

                        }
                        else if (endProgram == 3)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet3.Name + ".");

                        }
                        else if (endProgram == 4)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet4.Name + ".");

                        }

                    }

                    else if (endProgram == 2)
                    {
                        Console.WriteLine("Okay, so you'd like to feed the pets.\n\n");
                        Console.WriteLine("All the pets have been feed.\n\n");
                    }

                    else if (endProgram == 3)
                    {
                        Console.WriteLine("Okay, so you'd  to like play with a pets. Please choose one.\n\n");
                        Console.WriteLine("For " + myAnimalHouse.MyPet1.Name + " type 1");
                        Console.WriteLine("For " + myAnimalHouse.MyPet2.Name + " type 2");
                        Console.WriteLine("For " + myAnimalHouse.MyPet3.Name + " type 3");
                        Console.WriteLine("For " + myAnimalHouse.MyPet4.Name + " type 4");
                        Console.WriteLine("Which pet would you like to play with?\n\n");
                        Console.Write("> ");
                        endProgram = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        if (endProgram == 1)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet1.Name + ".");

                        }
                        else if (endProgram == 2)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet2.Name + ".");

                        }
                        else if (endProgram == 3)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet3.Name + ".");

                        }
                        else if (endProgram == 4)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet4.Name + ".");

                        }

                    }

                    else if (endProgram == 4)
                    {
                        Console.WriteLine("Okay, you want to pay your pet bills.");
                        Console.WriteLine("You paid the pet bills.");
                    }


                }

                else if (endProgram == 2)
                {
                    Console.WriteLine("Thank you for volunteering at the Unicorn Pet Shelter!\n\n");
                    Console.WriteLine("This is the status of your pets:\n\n");
                    Console.WriteLine("Name  | Hunger | Thrist | Bordom");
                    Console.WriteLine("------|--------|--------|--------");
                    Console.WriteLine(myAnimalHouse.MyPet4.Name + "|   83   |    34  |    23  "); //make sure to fill in block
                    Console.WriteLine(myAnimalHouse.MyPet4.Name + "|   69   |    49  |     2  "); //make sure to fill in block
                    Console.WriteLine(myAnimalHouse.MyPet4.Name + "|   39   |    18  |    88  "); //make sure to fill in block
                    Console.WriteLine(myAnimalHouse.MyPet4.Name + "|   59   |    19  |    37 \n\n "); //make sure to fill in block
                    Console.WriteLine("What would you like to do next?\n\n");
                    Console.WriteLine("1. Feed the pets");
                    Console.WriteLine("2. Water the pets");
                    Console.WriteLine("3.Play with the pets");
                    Console.WriteLine("4. Quit\n\n");
                    Console.Write("> ");
                    endProgram = int.Parse(Console.ReadLine());
                    Console.WriteLine();

                if (endProgram == 1)
                    {
                        Console.WriteLine("Okay, so you'd like to feed the pets.\n\n");
                        Console.WriteLine("All the pets hve been feed.\n\n");
                    }

                else if (endProgram == 2)
                    {
                        Console.WriteLine("Okay, so you'd like to water the pets.\n\n");
                        Console.WriteLine("All the pets have been water.\n\n");
                    }

                else if (endProgram == 3)
                    {
                        Console.WriteLine("Okay, so you'd  to like play with a pets. Please choose one.\n\n");
                        Console.WriteLine("For " + myAnimalHouse.MyPet1.Name + " type 1");
                        Console.WriteLine("For " + myAnimalHouse.MyPet2.Name + " type 2");
                        Console.WriteLine("For " + myAnimalHouse.MyPet3.Name + " type 3");
                        Console.WriteLine("For " + myAnimalHouse.MyPet4.Name + " type 4");
                        Console.WriteLine("Which pet would you like to play with?\n\n");
                        Console.Write("> ");
                        endProgram = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        if (endProgram == 1)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet1.Name + ".");

                        }
                        else if (endProgram == 2)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet2.Name + ".");

                        }
                        else if (endProgram == 3)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet3.Name + ".");

                        }
                        else if (endProgram == 4)
                        {
                            Console.WriteLine("Okay you adopted with " + myAnimalHouse.MyPet4.Name + ".");

                        }

                    }
                    else
                    {
                        isEndProgram = true;
                    }
              

                }
                 else
                {
                    isEndProgram = true;
                }

                Console.WriteLine("\n\n");
            } while (!isEndProgram);
        }
    }
}
