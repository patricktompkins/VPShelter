﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualPetShelter 
{
    class VirtualPetShelter
    {
        //fields
        private VirtualPet myPet1 = new VirtualPet();
        private VirtualPet myPet2 = new VirtualPet();
        private VirtualPet myPet3 = new VirtualPet();
        private VirtualPet myPet4 = new VirtualPet();
        private Manager myMan = new Manager();
        private Volunteer myVol = new Volunteer();

        //properties
        public VirtualPet MyPet1
        {
            get { return this.myPet1; }
            set { this.myPet1 = value; }
        }

        public VirtualPet MyPet2
        {
            get { return this.myPet2; }
            set {this.myPet2 = value; }
        }

        public VirtualPet MyPet3
        {
            get { return this.myPet3; }
            set { this.myPet3 = value;  }
        }

        public VirtualPet MyPet4
        {
            get { return this.myPet4; }
            set { this.myPet4 = value; }
        }

        public Manager MyMan
        {
            get { return this.myMan; }
            set { this.myMan = value; }
        }

        public Volunteer MyVol
        {
            get { return this.myVol; }
            set { this.myVol = value; }
        }


        //contructors

        public VirtualPetShelter()
        {
            //Default Constructor
        }




    }
}

