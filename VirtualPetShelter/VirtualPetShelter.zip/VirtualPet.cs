﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualPetShelter
{
    class VirtualPet
   {
        //fields 
        private string petType;
        private int age;
        private bool likesToTalk;
        private int hungaryLevel;
       
        private string petDiet;
        private string name;
        private string description;

        //properties
        public string PetType
        {
            get { return this.petType; }
            set { this.petType = value; }
        }
    
        public int Age
        {
            get { return this.age; }
            set { this.age = value; }
        }

        public bool LikesToTalk
        {
            get { return this.likesToTalk; }
            set { this.likesToTalk = value; }
        }

        public int HungaryLevel
        {
            get { return this.hungaryLevel; }
            set { this.hungaryLevel = value; }
        }

                
        public string PetDiet
        {
            get { return this.petDiet; }
            set { this.petDiet = value; }

        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }
        //Constructors

        public VirtualPet()
        {

            //default constructor
        }

     
        public VirtualPet(string name, string description)
        {
            this.petType = "Horse";
            this.age = 0;
            this.likesToTalk = true;
            this.hungaryLevel = 12;
            this.petDiet = "Wheaties";
            this.name = name;
            this.description = description;
        }

        public VirtualPet(string petType, int age, bool likesToTalk, int hungaryLevel, string collegeTeam, string petDiet, string name, string description)
        {
            this.petType = petType;
            this.age = age;
            this.likesToTalk = likesToTalk;
            this.hungaryLevel = hungaryLevel;
            this.petDiet = petDiet;
            this.name = name;
            this.description = description;

        }

        //Methods
        public void TalkToThePet()
        {
            if (likesToTalk)
            {
                Console.WriteLine("Yes I like to talk.");
            }
            else
            {
                Console.WriteLine("No I don't like to talk");
            }

        }

        public void ProvideInformation()
        {
            Console.WriteLine("I am a {0} years old {1} that {2} to talk.", age, petType, likesToTalk);
        }

        public void AskQuestion(int question)
        {
            switch (question)
            {
                case 1:
                    Console.WriteLine(age);
                    break;

                case 2:
                    Console.WriteLine(likesToTalk);
                    break;
                case 3:
                    Console.WriteLine(petType);
                    break;

                default:
                    break;


            }
        }

        

        public void feedME()
        {
        }

        public void PlayWithMe()
        {

        }
        //TICK METHOD
        public void Tick()
        {
            string level;
            string speak;


            HungaryLevel = HungaryLevel + 1;


            Console.WriteLine("I am Mr. Ed the talking {0}.", PetType);
            Console.WriteLine("I am {0} years old.", Age);
            if (LikesToTalk)
            {
                speak = "like to talk";
            }
            else
            {

                speak = "do not like to talk";
            }
            Console.WriteLine("I {0} all the time.", speak);

            if (HungaryLevel < 10)
            {
                level = "I am not hungary.";
            }
            else
            {
                level = "I am hungary.";
            }
            Console.WriteLine(level);
            
            Console.WriteLine();
        }











    }
}